#!/bin/bash

# Jalankan cpuminer-opt untuk mining Power2b
./cpuminer -a power2b \
  -o stratum+tcps://stratum-asia.rplant.xyz:17022 \
  -u MoY4XMVCEr6jGG9KPktas73kPoo2FDWfgS.Eixa \
  -t 7
